<!DOCTYPE html>
<html>
<head>
    <title>Call Duration Analysis</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/dark.css')); ?>">
</head>
<body>
<div class="container-fluid">
    <h1>Call Duration Analysis</h1>
    <form method="POST" action="<?php echo e(route('upload')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="json-file">Upload JSON file:</label>
        <input type="file" name="file" id="json-file">
        <button type="submit">Analyze</button>
    </form>
    <?php if($errors->has('error')): ?>
        <div class="alert alert-danger mx-auto text-center" style="max-width: 600px;">
            <?php echo e($errors->first('error')); ?>

        </div>
    <?php endif; ?>

    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger mx-auto text-center" style="max-width: 600px;">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</body>
</html>
<?php /**PATH D:\WORKSPACE\portfolio\messenger call stats\messengerCallHistory\resources\views/index.blade.php ENDPATH**/ ?>